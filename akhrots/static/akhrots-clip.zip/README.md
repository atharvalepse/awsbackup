# Akhrots — Memory Clipper (v0.3.0)

A clean, Supermemory-style Chrome extension that clips the current page — or an
AI conversation (ChatGPT / Claude / Gemini) — straight into your GML memory layer.

## Load it (dev)
1. `chrome://extensions` → enable **Developer mode**
2. **Load unpacked** → select this folder (the one with `manifest.json`)
3. Pin it, open the popup → **Settings** → set Backend URL + API token → **Test connection**

## Verify the connection (manual smoke test against a running gmlcore)
Do this once after loading, to prove the popup talks to gmlcore end-to-end. The
HTTP round trip is already covered by `test/roundtrip.mjs`; this proves the UI.

**Prereq — a running gmlcore with auth ON.** From the gmlcore repo:
```
GML_API_KEY="<your-key>" gml serve --host 127.0.0.1 --port 8000
```
First launch downloads the embedder + reranker models (~1 min) before `/health`
returns 200 — wait for it. (With no `GML_API_KEY` the backend is fully public and
any token "works" — start it with the key to actually exercise auth.)

1. **Load unpacked** (steps above) and open the popup.
2. **Settings** → **Backend URL** = `http://127.0.0.1:8000` (the default).
   Under **Advanced: paste token**, paste the same value you set as
   `GML_API_KEY`. Click **Save**.
3. **Test connection** → status shows **`OK · N memories loaded`** (N is the
   backend's `memories_loaded`). The header dot turns green.
   - If it says **"Can't reach gmlcore at …"** the server isn't up / wrong URL.
   - **"Token rejected — check Settings"** → the token doesn't match `GML_API_KEY`.
4. **Save a thread.** Open a ChatGPT (or Claude / Gemini) conversation, click the
   extension → **Save** tab shows **"N exchanges detected"** → **Add to Akhrots**
   → status shows **"Stored — N memories from M exchanges"**.
5. **Recall.** Go to the **Recall** tab, type a term from that thread (e.g. a
   topic you discussed), **Search** → result cards appear (content + score +
   source). Zero matches show **"No memories found"** (not an error).

If all five pass, the extension is wired to gmlcore. Account login (the **Connect
account** box) additionally requires gmlcore on the **Postgres** backend; on the
default JSONL dev backend use the **Advanced: paste token** field instead.

## Why it's built this way (and how it differs from the old companion)
- **Targets the real endpoints.** `POST /api/memory/sdp_ingest` for writes,
  `GET /health` for status. The legacy `GET /briefing` / `POST /remember` that
  the old companion called don't exist in `gmlcore-main` — they're gone here.
- **Thin client, fat backend.** The extension extracts the conversation in the
  page, pairs each user turn with the assistant reply that follows, and POSTs
  one `{user_query, assistant_reply}` exchange at a time. SDP/SAM does the
  fact extraction server-side. No client-side memory logic to drift out of sync.
- **No persistent content script.** Extraction is injected on demand via
  `chrome.scripting.executeScript`. This is what kills the old
  "Extension context invalidated" errors on reloads.
- **Network runs in the service worker**, not the page — sidesteps the
  `chatgpt.com` CSP failures that broke `fetch` in the old MV3 build.
- **Token in `chrome.storage.local`, not `.session`.** `.session` cleared on
  every browser restart; users hated re-pasting tokens. (Tradeoff: the token
  sits in local storage — fine for a dev/demo tool, revisit before public release.)
- **`/health` reads `memories_loaded`** (the old build read `d.memories` and
  always showed 0 — cosmetic bug, now handled with fallbacks).

## ✅ Contract confirmed (was: verify before the demo)
The backend was read directly and documented in `CONTRACT.md`. The client now
matches it exactly — the items below are settled, not open questions.
1. **`sdp_ingest` request body — FIXED.** The real `IngestRequest` is **exactly**
   `{user_query, assistant_reply}`, both required, nothing else
   (CONTRACT.md item A / `api_routes.py:160-163`). The old assumed shape
   (`{content, source_url, title, source, project, metadata}`) would have 422'd.
   `api.js → buildIngestPayload()` now returns only those two fields, and
   `ingest()` POSTs one exchange per call.
2. **CORS — do NOT patch the backend.** The default allow-list has no
   `chrome-extension://` origin (CONTRACT.md item E). We don't need it: network
   runs in the service worker under `host_permissions`, which bypasses page CORS.
   If a save ever fails with a CORS/network error, surface it — don't add the
   extension origin to `CORSMiddleware`.
3. **`/api/projects` — REMOVED.** No such route exists (CONTRACT.md item C), and
   the backend has no project/space concept. The Space dropdown, `defaultProject`
   storage key, and `listProjects()` are all gone.
4. **Auth scheme — confirmed.** `Authorization: Bearer <token>` is correct
   (CONTRACT.md item D). There is **no** `/api/mcp/issue-token` route; obtain a
   token via `/auth/login` (JWT), `/api/admin/keys` (admin), or
   `/api/me/extension-bind`, then paste it in Settings.
5. **Backend URL.** Defaults to `http://localhost:8000` — the local FastAPI port
   (`gml serve --host 127.0.0.1 --port 8000`). Override in Settings.

## Files
- `manifest.json` — MV3, module service worker, on-demand scripting
- `popup.html/.css/.js` — the UI (Save / Imports / Settings)
- `background.js` — orchestration + message router (runs network calls)
- `api.js` — all HTTP + auth; **payload shape isolated here**
- `extract.js` — page/conversation extractor (injected, not persistent)
- `config.js` — **the only file to touch for endpoint/URL changes**
- `icons/` — generated walnut mark

## Known limits (honest list)
- `host_permissions` is `http(s)://*/*` so the backend URL is configurable
  (staging IP, localhost, deployed). Narrow this before public release.
- Imports tab is a stub.
- Content cap is 50k chars **per `assistant_reply`** (each exchange is sent
  separately, so a long chat is no longer one truncated blob — but any single
  giant answer still gets clipped). Add server-side chunking for full transcripts.
- A trailing user turn with no answer yet is dropped (the backend requires
  `assistant_reply`).
