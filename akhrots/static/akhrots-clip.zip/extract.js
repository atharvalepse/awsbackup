// extract.js — injected on demand with chrome.scripting.executeScript.
// We deliberately do NOT register a persistent content script: that's what
// caused "Extension context invalidated" errors on reloads in the old build.
// This runs in the page, returns a plain object, and is gone.
//
// IMPORTANT: extractPage must be fully self-contained — it is serialized and
// injected, so it cannot reference anything outside its own body (no imports,
// no module-scope helpers).
//
// The backend ingests one exchange at a time as { user_query, assistant_reply }
// (CONTRACT.md item A / api_routes.py:160-163). So extractPage walks the
// conversation in DOM order, pairs each user turn with the assistant reply that
// immediately follows it, and returns those pairs. If the site's structured
// selectors have gone stale (these vendors change their DOM often), it FALLS
// BACK to capturing the whole visible conversation as a single exchange — so a
// save never silently fails just because a selector changed.

export function extractPage() {
  const host = location.hostname;

  const clean = (s) => (s || "").replace(/\s+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();

  // Per-assistant-reply payload cap (chars). Applied per reply so one huge
  // answer can't dominate the batch.
  const REPLY_CAP = 50000;

  // Walk an ordered list of {role: "user"|"assistant", text} turns and pair
  // each user turn with the assistant reply that immediately follows it. A
  // trailing user turn with no answer yet is dropped (CONTRACT.md item A —
  // assistant_reply is required, so an unpaired user turn can't be sent).
  function pairTurns(turns) {
    const pairs = [];
    for (let i = 0; i < turns.length; i++) {
      if (turns[i].role !== "user") continue;
      const next = turns[i + 1];
      if (next && next.role === "assistant") {
        const user_query = clean(turns[i].text);
        const assistant_reply = clean(next.text).slice(0, REPLY_CAP);
        if (user_query && assistant_reply) {
          pairs.push({ user_query, assistant_reply });
        }
        i++; // consume the assistant turn we just paired
      }
    }
    return pairs;
  }

  // --- Site adapters: return ordered {role, text} turns, or null if absent ---

  // ChatGPT tags every message with data-message-author-role: user | assistant |
  // system | tool. Keep only user/assistant; dropping system/tool stops them
  // from mis-pairing with a real turn.
  function chatgpt() {
    const nodes = [...document.querySelectorAll("[data-message-author-role]")];
    if (!nodes.length) return null;
    return nodes
      .map((node) => ({
        role: node.getAttribute("data-message-author-role"),
        text: node.innerText,
      }))
      .filter((t) => t.role === "user" || t.role === "assistant");
  }

  // Claude's markers move around between builds, so accept several known shapes
  // for both roles. Anything that isn't flagged as a user turn is treated as an
  // assistant turn.
  function claude() {
    const nodes = [...document.querySelectorAll(
      '[data-testid="user-message"], [data-testid="assistant-message"], ' +
      '.font-user-message, .font-claude-message'
    )];
    if (!nodes.length) return null;
    return nodes.map((node) => {
      const isUser = node.matches('[data-testid="user-message"], .font-user-message');
      return { role: isUser ? "user" : "assistant", text: node.innerText };
    });
  }

  function gemini() {
    const nodes = [...document.querySelectorAll("user-query, model-response")];
    if (!nodes.length) return null;
    return nodes.map((node) => ({
      role: node.tagName.toUpperCase() === "USER-QUERY" ? "user" : "assistant",
      text: node.innerText,
    }));
  }

  // Last-resort capture: the visible conversation/page text as one blob. Prefer
  // the main content region so we skip nav/sidebar chrome where possible.
  function wholeText() {
    const main = document.querySelector("main, article, [role=main]") || document.body;
    return main.innerText;
  }

  let source = "browser";
  let turns = null;
  if (/chatgpt\.com|chat\.openai\.com/.test(host)) { source = "chatgpt"; turns = chatgpt(); }
  else if (/claude\.ai/.test(host)) { source = "claude"; turns = claude(); }
  else if (/gemini\.google\.com/.test(host)) { source = "gemini"; turns = gemini(); }

  // Best path: structured user/assistant pairs.
  let pairs = turns ? pairTurns(turns) : [];

  // Fallback when structured extraction yields nothing usable — stale selectors
  // on a known chat site, OR a plain (non-chat) page. Capture the visible text
  // as ONE exchange so the user always saves something instead of hitting a
  // hard "No conversation found". Keep the detected source so it's tagged right.
  if (pairs.length === 0) {
    const text = clean(wholeText()).slice(0, REPLY_CAP);
    if (text) {
      const label = source === "browser"
        ? `Saved page: ${document.title}`
        : `Conversation captured from ${host}`;
      pairs = [{ user_query: label, assistant_reply: text }];
    }
  }

  return {
    source,
    title: document.title,
    url: location.href,
    pairs,
  };
}
