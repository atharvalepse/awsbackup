// api.js — all network + auth in one place.
import { DEFAULTS, ENDPOINTS, STORAGE_KEYS } from "./config.js";

async function getStored() {
  const d = await chrome.storage.local.get([
    STORAGE_KEYS.token,
    STORAGE_KEYS.user,
    STORAGE_KEYS.baseUrl,
  ]);
  return {
    token: d[STORAGE_KEYS.token] || "",
    user: d[STORAGE_KEYS.user] || "",
    baseUrl: d[STORAGE_KEYS.baseUrl] || DEFAULTS.baseUrl,
  };
}

function authHeaders(token) {
  const h = { "Content-Type": "application/json" };
  // CONTRACT.md item D: backend expects `Authorization: Bearer <token>`.
  if (token) h["Authorization"] = `Bearer ${token}`;
  return h;
}

// Defensive fetch: timeout + JSON-or-text + structured errors.
// Network calls run in the SERVICE WORKER, not the content script —
// that sidesteps the page CSP issues that broke fetch on chatgpt.com, and
// requests sent under host_permissions are not subject to page CORS
// (CONTRACT.md item E: the backend grants no chrome-extension origin).
async function call(path, { method = "GET", body, token, baseUrl } = {}) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 15000);
  let res;
  try {
    res = await fetch(`${baseUrl}${path}`, {
      method,
      headers: authHeaders(token),
      body: body ? JSON.stringify(body) : undefined,
      signal: ctrl.signal,
    });
  } catch (e) {
    clearTimeout(timer);
    // AbortError == our 15s timeout fired. Everything else here is a transport
    // failure (refused connection, DNS, offline). The browser collapses all of
    // those to a generic "Failed to fetch", so we can't single out "refused" —
    // one reachability message covers them, naming the URL so it's actionable.
    if (e.name === "AbortError") throw new Error("gmlcore timed out");
    throw new Error(`Can't reach gmlcore at ${baseUrl}`);
  }
  clearTimeout(timer);

  const text = await res.text();
  let data;
  try { data = text ? JSON.parse(text) : {}; } catch { data = { raw: text }; }

  if (!res.ok) {
    // Map the codes the UI cares about to clear, user-facing messages — never a
    // raw body or stack. Other statuses fall back to "<status> <detail>".
    if (res.status === 401) throw new Error("Token rejected — check Settings");
    if (res.status === 422) throw new Error("Bad request — contract mismatch");
    const detail = data?.detail || data?.message || res.statusText;
    throw new Error(`${res.status} ${detail}`);
  }
  return data;
}

export async function checkHealth() {
  const { baseUrl, token } = await getStored();
  const data = await call(ENDPOINTS.health, { token, baseUrl });
  // Backend returns `memories_loaded` (CONTRACT.md item B). The fallbacks cover
  // /api/health (`memories`) and any future shape without breaking.
  const count =
    data.memories_loaded ?? data.memories ?? data.count ?? null;
  return { ok: true, count, baseUrl, raw: data };
}

// The real IngestRequest has EXACTLY two required fields and nothing else
// (CONTRACT.md item A / api_routes.py:160-163). Isolated so a backend Pydantic
// change is a one-line fix.
function buildIngestPayload({ user_query, assistant_reply }) {
  return { user_query, assistant_reply };
}

// POST each {user_query, assistant_reply} pair to /api/memory/sdp_ingest
// sequentially. The backend ingests one exchange per call, so we loop. One
// failed pair does not abort the batch — we collect failures and keep going.
//
// `onProgress(done, total)` (optional) fires before each pair is POSTed so the
// caller can render "Saving 3/7…".
export async function ingest(pairs, onProgress) {
  const { baseUrl, token } = await getStored();
  if (!token) throw new Error("No token set. Add one in Settings.");

  const total = pairs.length;
  let created = 0;
  const failures = [];

  for (let index = 0; index < total; index++) {
    if (onProgress) onProgress(index, total);
    const payload = buildIngestPayload(pairs[index]);
    try {
      const res = await call(ENDPOINTS.ingest, {
        method: "POST",
        body: payload,
        token,
        baseUrl,
      });
      // IngestResponse: prefer the length of `created` (the memory ids),
      // fall back to `count` (CONTRACT.md item A).
      const n = Array.isArray(res?.created) ? res.created.length : (res?.count ?? 0);
      created += n;
    } catch (e) {
      failures.push({ index, error: e.message });
    }
  }

  return { exchanges: total, created, failures };
}

// Retrieve memories for a query. POSTs the real RecallRequest shape
// (CONTRACT.md item F / api_routes.py:134-146): only `query` is required;
// `top_k` defaults to 5 server-side — we ask for 10. Returns the `results`
// array, each element { memory: {...ApiMemory}, score, why }.
export async function recall(query) {
  const { baseUrl, token } = await getStored();
  if (!token) throw new Error("No token set. Add one in Settings.");
  const data = await call(ENDPOINTS.recall, {
    method: "POST",
    body: { query, top_k: 10 },
    token,
    baseUrl,
  });
  return Array.isArray(data?.results) ? data.results : [];
}

// ── Account onboarding (CONTRACT.md §G) ──────────────────────────────────────
// We never log the password or any token in here.

// G1: POST /auth/login { email, password }. The token lives in `access_token`
// (a short-lived JWT); `user_id` identifies the account. Public route — no
// existing credential needed.
async function login(email, password) {
  const { baseUrl } = await getStored();
  const data = await call(ENDPOINTS.login, {
    method: "POST",
    body: { email, password },
    baseUrl,
  });
  return { jwt: data.access_token, userId: data.user_id };
}

// G2: POST /api/me/extension-bind, authenticated with the JWT from G1 in the
// Authorization header. NO request body — identity comes from the bearer token.
// Returns { user_id, token } where `token` is the long-lived, per-user,
// extension-scoped `gml_…` key (NOT a JWT, NOT the master key).
async function bindExtension(jwt) {
  const { baseUrl } = await getStored();
  const data = await call(ENDPOINTS.extensionBind, {
    method: "POST",
    token: jwt,          // Bearer <JWT> — the master key cannot bind (§G2)
    baseUrl,
  });
  return { userId: data.user_id, scopedToken: data.token };
}

// G3: chain login -> JWT -> bind(JWT) -> scoped key. Persist the SCOPED key as
// the credential the extension uses thereafter — never the JWT, never the
// master key — plus the returned identity as gml_user. Returns { user }.
export async function connect(email, password) {
  const { jwt, userId } = await login(email, password);
  const { scopedToken, userId: boundUserId } = await bindExtension(jwt);
  const user = boundUserId || userId;
  await chrome.storage.local.set({
    [STORAGE_KEYS.token]: scopedToken,
    [STORAGE_KEYS.user]: user,
  });
  return { user };
}

export { getStored };
