// popup.js
import { STORAGE_KEYS, DEFAULTS } from "./config.js";

const $ = (id) => document.getElementById(id);
const send = (msg) =>
  new Promise((resolve) => chrome.runtime.sendMessage(msg, resolve));

// ---- Tabs ----
document.querySelectorAll(".tab").forEach((tab) => {
  tab.addEventListener("click", () => {
    const name = tab.dataset.tab;
    document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("is-active", t === tab));
    document.querySelectorAll(".panel").forEach((p) =>
      p.classList.toggle("is-active", p.dataset.panel === name)
    );
  });
});

// ---- Status helper ----
function setStatus(el, text, kind = "info") {
  el.textContent = text;
  el.className = `status ${kind}`;
}

// call() (api.js) already returns clear, user-facing messages for every failure
// mode — "gmlcore timed out", "Can't reach gmlcore at <url>", "Token rejected —
// check Settings" (401), "Bad request — contract mismatch" (422). This only
// guards against an empty/undefined error so the popup never shows blank status.
function friendlyError(msg) {
  return msg || "Something went wrong";
}

// ---- Load current-tab preview ----
async function loadPreview() {
  const r = await send({ type: "PREVIEW" });
  if (!r?.ok) return;
  const { title, url } = r.data;
  $("pageTitle").textContent = title || url || "Current tab";
  try {
    const u = new URL(url);
    $("pageUrl").textContent = u.host + u.pathname;
    $("favicon").src = `https://www.google.com/s2/favicons?domain=${u.host}&sz=32`;
    const m = { "chatgpt.com": "chatgpt", "chat.openai.com": "chatgpt",
      "claude.ai": "claude", "gemini.google.com": "gemini" }[u.host];
    if (m) { const p = $("srcPill"); p.textContent = m; p.hidden = false; }
  } catch { $("pageUrl").textContent = url || ""; }
}

// ---- Count detectable exchanges on the current tab ----
// Each exchange becomes one POST /api/memory/sdp_ingest (CONTRACT.md item A).
async function loadExchangeCount() {
  const el = $("detected");
  el.textContent = "Scanning page…";
  const r = await send({ type: "COUNT" });
  if (!r?.ok) { el.textContent = ""; return; }
  const n = r.data?.count ?? 0;
  el.textContent = n === 1 ? "1 exchange detected" : `${n} exchanges detected`;
}

// ---- Health dot + user ----
async function refreshHealth() {
  const r = await send({ type: "HEALTH" });
  const dot = $("connDot");
  if (r?.ok) {
    dot.className = "dot ok";
    dot.title = `Connected · ${r.data.count ?? "?"} memories`;
  } else {
    dot.className = "dot err";
    dot.title = r?.error || "Not connected";
  }
  const { [STORAGE_KEYS.user]: user } = await chrome.storage.local.get(STORAGE_KEYS.user);
  if (user) $("who").textContent = `${user}'s`;
}

// ---- Live save progress: the background worker emits PROGRESS per exchange ----
chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === "PROGRESS") {
    // done is 0-based (fired before each POST); show 1-based for humans.
    setStatus($("status"), `Saving ${msg.done + 1}/${msg.total}…`, "info");
  }
});

// ---- Save flow ----
$("saveBtn").addEventListener("click", async () => {
  const btn = $("saveBtn");
  const label = $("saveBtnLabel");
  btn.disabled = true; btn.classList.add("busy");
  label.textContent = "Saving…";
  setStatus($("status"), "Extracting + sending to SDP…", "info");

  const r = await send({ type: "SAVE" });

  btn.classList.remove("busy"); btn.disabled = false;
  if (r?.ok) {
    label.textContent = "Saved ✓";
    const saved = r.data?.saved || {};
    const created = saved.created ?? 0;
    const exchanges = saved.exchanges ?? 0;
    const failed = saved.failures?.length || 0;
    let text = `Stored — ${created} memories from ${exchanges} exchanges`;
    if (failed) text += ` (${failed} failed)`;
    setStatus($("status"), text, failed ? "err" : "ok");
    setTimeout(() => (label.textContent = "Add to Akhrots"), 2200);
  } else {
    label.textContent = "Add to Akhrots";
    setStatus($("status"), friendlyError(r?.error) || "Save failed", "err");
  }
});

// Compact, defensive date formatter for ApiMemory.timestamp (ISO-8601, §F).
// Returns a short relative label for recent times ("2h ago"), else "Jun 8".
// Returns null if the input is absent or unparseable — caller renders nothing.
function formatTime(iso) {
  if (!iso) return null;
  const ms = Date.parse(iso);
  if (Number.isNaN(ms)) return null;
  const diff = Date.now() - ms;
  const min = Math.floor(diff / 60000);
  if (diff >= 0 && min < 60) return min <= 0 ? "just now" : `${min}m ago`;
  const hr = Math.floor(min / 60);
  if (diff >= 0 && hr < 24) return `${hr}h ago`;
  return new Date(ms).toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

// ---- Recall flow ----
// Renders results from POST /api/memory/recall. Each result is
// { memory: {...ApiMemory}, score, why } (CONTRACT.md item F).
function renderResults(results) {
  const box = $("results");
  box.innerHTML = "";
  for (const r of results) {
    const m = r.memory || {};
    const card = document.createElement("article");
    card.className = "result-card";

    // Body text: ApiMemory.content (item F). summary_short is a shorter variant.
    const body = document.createElement("div");
    body.className = "result-text";
    body.textContent = m.content || m.summary_short || "(no content)";
    card.appendChild(body);

    // Rerank explanation: result.why (§F, str|null). Render UNDER the content
    // only when it's a non-empty string — null/empty renders nothing at all.
    if (typeof r.why === "string" && r.why.trim()) {
      const why = document.createElement("div");
      why.className = "result-why";
      why.textContent = `↳ matched: ${r.why.trim()}`;
      card.appendChild(why);
    }

    // Meta row: score (top-level result.score) + source + id + time — all item F.
    const meta = document.createElement("div");
    meta.className = "result-meta";

    if (typeof r.score === "number") {
      const score = document.createElement("span");
      score.className = "chip score";
      score.textContent = r.score.toFixed(3);
      meta.appendChild(score);
    }
    if (m.source) {
      const src = document.createElement("span");
      src.className = "chip";
      src.textContent = m.source;
      meta.appendChild(src);
    }
    if (m.id) {
      const id = document.createElement("span");
      id.className = "chip id";
      id.textContent = m.id;
      meta.appendChild(id);
    }
    // Memory time: ApiMemory.timestamp (§F, ISO-8601 — NOT created_at). Only
    // shown when present and parseable (formatTime returns null otherwise).
    const when = formatTime(m.timestamp);
    if (when) {
      const time = document.createElement("span");
      time.className = "result-time";
      time.textContent = when;
      meta.appendChild(time);
    }
    card.appendChild(meta);
    box.appendChild(card);
  }
}

$("recallForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const query = $("recallQuery").value.trim();
  if (!query) return; // empty query: do nothing

  const btn = $("recallBtn");
  btn.disabled = true;
  $("results").innerHTML = "";
  setStatus($("recallStatus"), "Searching…", "info");

  const r = await send({ type: "RECALL", query });
  btn.disabled = false;

  if (!r?.ok) {
    setStatus($("recallStatus"), friendlyError(r?.error) || "Recall failed", "err");
    return;
  }
  const results = r.data || [];
  if (!results.length) {
    setStatus($("recallStatus"), "No memories found", "info");
    return;
  }
  setStatus($("recallStatus"), `${results.length} result${results.length === 1 ? "" : "s"}`, "ok");
  renderResults(results);
});

// ---- Connect account (CONTRACT.md §G) ----
// login -> extension-bind -> the SCOPED token is stored by api.connect. We never
// touch the password/token here beyond reading the inputs.
$("connectBtn").addEventListener("click", async () => {
  const email = $("connectEmail").value.trim();
  const password = $("connectPassword").value;
  if (!email || !password) {
    setStatus($("connectStatus"), "Enter email and password", "err");
    return;
  }
  const btn = $("connectBtn");
  btn.disabled = true;
  setStatus($("connectStatus"), "Connecting…", "info");

  // Persist the typed Backend URL first so the chained calls hit the right host.
  await chrome.storage.local.set({
    [STORAGE_KEYS.baseUrl]: $("baseUrl").value.trim().replace(/\/$/, ""),
  });

  const r = await send({ type: "CONNECT", email, password });
  btn.disabled = false;
  $("connectPassword").value = ""; // don't leave the password sitting in the DOM

  if (r?.ok) {
    const user = r.data?.user || "account";
    setStatus($("connectStatus"), `Connected as ${user}`, "ok");
    $("who").textContent = `${user}'s`;
    refreshHealth();
  } else {
    // Show the exact backend error (e.g. "401 invalid email or password",
    // "501 email/password auth requires the Postgres backend").
    setStatus($("connectStatus"), r?.error || "Connect failed", "err");
  }
});

// ---- Settings ----
async function loadSettings() {
  const d = await chrome.storage.local.get(Object.values(STORAGE_KEYS));
  $("baseUrl").value = d[STORAGE_KEYS.baseUrl] || DEFAULTS.baseUrl;
  $("token").value = d[STORAGE_KEYS.token] || "";
}

$("saveSettingsBtn").addEventListener("click", async () => {
  await chrome.storage.local.set({
    [STORAGE_KEYS.baseUrl]: $("baseUrl").value.trim().replace(/\/$/, ""),
    [STORAGE_KEYS.token]: $("token").value.trim(),
  });
  setStatus($("settingsStatus"), "Saved", "ok");
  refreshHealth();
});

$("testBtn").addEventListener("click", async () => {
  setStatus($("settingsStatus"), "Pinging /health…", "info");
  // persist first so the test uses the values currently typed
  await chrome.storage.local.set({
    [STORAGE_KEYS.baseUrl]: $("baseUrl").value.trim().replace(/\/$/, ""),
    [STORAGE_KEYS.token]: $("token").value.trim(),
  });
  const r = await send({ type: "HEALTH" });
  if (r?.ok) setStatus($("settingsStatus"), `OK · ${r.data.count ?? "?"} memories loaded`, "ok");
  else setStatus($("settingsStatus"), r?.error || "Failed", "err");
  refreshHealth();
});

// ---- Init ----
loadPreview();
loadExchangeCount();
loadSettings();
refreshHealth();
