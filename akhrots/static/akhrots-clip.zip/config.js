// config.js — single source of truth for the GML backend contract.
// If the backend changes, this is the ONLY file you touch.
//
// Verified against gmlcore (see CONTRACT.md):
//  - POST /api/memory/sdp_ingest takes EXACTLY { user_query, assistant_reply }
//    (CONTRACT.md item A / api_routes.py:160-163).
//  - GET /health returns { memories_loaded, ... } (CONTRACT.md item B).
//  - There is NO /api/projects route — the project/space concept does not
//    exist on the backend (CONTRACT.md item C). Removed here.

export const DEFAULTS = {
  // Local dev: the FastAPI app runs on 127.0.0.1:8000 by default
  // (gml serve --host 127.0.0.1 --port 8000; orchestration/cli.py:505-506,
  // deploy/systemd-gml-api.service:19). Use the IPv4 literal 127.0.0.1, NOT
  // "localhost" — on some machines localhost resolves to IPv6 ::1 first and the
  // backend only binds IPv4, which surfaces as a confusing "can't reach" error.
  // Override per-user in Settings (stored in chrome.storage.local).
  baseUrl: "http://127.0.0.1:8000",
};

export const ENDPOINTS = {
  health: "/health",                       // -> { memories_loaded, ... } (item B)
  ingest: "/api/memory/sdp_ingest",        // POST { user_query, assistant_reply } (item A)
  recall: "/api/memory/recall",            // POST { query, top_k? } -> { results:[...] } (item F)
  synthesize: "/api/memory/synthesize",    // GET ?query=… -> assembled briefing blob (item F)
  login: "/auth/login",                    // POST { email, password } -> { access_token (JWT), user_id } (item G1)
  extensionBind: "/api/me/extension-bind", // POST (Bearer JWT, no body) -> { user_id, token } scoped key (item G2)
};

// chrome.storage.local keys. We use .local (not .session like the old build)
// so the token survives a browser restart — a popup that forgets your token
// every morning is the #1 reason people stop using an extension.
export const STORAGE_KEYS = {
  token: "gml_token",
  user: "gml_user",
  baseUrl: "gml_base_url",
};
