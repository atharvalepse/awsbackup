// background.js — service worker (MV3). Network + orchestration live here.
import { extractPage } from "./extract.js";
import { ingest, checkHealth, recall, connect } from "./api.js";

// Inject extractPage() into the active tab and return its result
// ({ source, title, url, pairs }). Throws on pages we can't script.
async function extractActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) throw new Error("No active tab.");

  if (/^(chrome|edge|about|chrome-extension):/.test(tab.url || "")) {
    throw new Error("Can't capture a browser-internal page.");
  }

  const [{ result } = {}] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: extractPage,
  });
  if (!result) throw new Error("Nothing readable found on this page.");
  return result;
}

// Capture the active tab, then ingest each exchange. Emits PROGRESS messages so
// the popup can show "Saving 3/7…".
async function captureActiveTab() {
  const capture = await extractActiveTab();
  if (!capture.pairs?.length) {
    throw new Error("No conversation found to save");
  }

  const saved = await ingest(capture.pairs, (done, total) => {
    // Fire-and-forget; the popup may be closed. Catch so a missing receiver
    // doesn't reject the save.
    chrome.runtime.sendMessage({ type: "PROGRESS", done, total }).catch(() => {});
  });

  return { capture, saved };
}

// Message router for the popup.
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    try {
      switch (msg.type) {
        case "PREVIEW": {
          const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
          sendResponse({ ok: true, data: { title: tab?.title, url: tab?.url } });
          break;
        }
        case "COUNT": {
          // Cheap pre-save probe: how many exchanges would we send?
          const capture = await extractActiveTab();
          sendResponse({
            ok: true,
            data: { count: capture.pairs?.length || 0, source: capture.source },
          });
          break;
        }
        case "SAVE":
          sendResponse({ ok: true, data: await captureActiveTab() });
          break;
        case "HEALTH":
          sendResponse({ ok: true, data: await checkHealth() });
          break;
        case "RECALL":
          sendResponse({ ok: true, data: await recall(msg.query) });
          break;
        case "CONNECT":
          // login (+ extension-bind) per CONTRACT.md §G. api.connect persists the
          // scoped token + identity; we return only the user, never the token.
          sendResponse({ ok: true, data: await connect(msg.email, msg.password) });
          break;
        default:
          sendResponse({ ok: false, error: "Unknown message type" });
      }
    } catch (e) {
      sendResponse({ ok: false, error: e.message });
    }
  })();
  return true; // keep the channel open for the async response
});
